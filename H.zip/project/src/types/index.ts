export interface CourseType {
  id: number;
  title: string;
  description: string;
  goals: string[];
  methods: string[];
  preview: string;
  icon: string;
}

export interface ReviewType {
  id: number;
  name: string;
  country: string;
  flag: string;
  text: string;
  rating: number;
}

export interface TimelineItemType {
  id: number;
  year: string;
  title: string;
  description: string;
  icon: string;
}

export interface DemoMaterialType {
  id: number;
  title: string;
  description: string;
  type: 'pdf' | 'video' | 'image' | 'slides';
  url: string;
  thumbnail: string;
}