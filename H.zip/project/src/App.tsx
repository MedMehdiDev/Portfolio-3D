import React, { useEffect } from 'react';
import Layout from './components/layout/Layout';
import HeroSection from './components/sections/HeroSection';
import AboutSection from './components/sections/AboutSection';
import TeachingSection from './components/sections/TeachingSection';
import CoursesSection from './components/sections/CoursesSection';
import ReviewsSection from './components/sections/ReviewsSection';
import MaterialsSection from './components/sections/MaterialsSection';
import { ThemeProvider } from './context/ThemeContext';

// Add custom CSS for effects
import './styles/3dStyles.css';

function App() {
  useEffect(() => {
    document.title = "Hassna Ben - CELTA Certified English Teacher";
  }, []);

  return (
    <ThemeProvider>
      <Layout>
        <HeroSection />
        <AboutSection />
        <TeachingSection />
        <CoursesSection />
        <ReviewsSection />
        <MaterialsSection />
      </Layout>
    </ThemeProvider>
  );
}

export default App;