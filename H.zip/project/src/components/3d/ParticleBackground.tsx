import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { useTheme } from '../../context/ThemeContext';

const generateParticles = (count: number) => {
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  
  for (let i = 0; i < count; i++) {
    const i3 = i * 3;
    positions[i3] = (Math.random() - 0.5) * 10;
    positions[i3 + 1] = (Math.random() - 0.5) * 10;
    positions[i3 + 2] = (Math.random() - 0.5) * 10;
    
    colors[i3] = Math.random() * 0.5 + 0.5;     // More towards purple
    colors[i3 + 1] = Math.random() * 0.3 + 0.2; // Less green
    colors[i3 + 2] = Math.random() * 0.6 + 0.4; // Blueish purple
  }
  
  return { positions, colors };
};

interface ParticleCloudProps {
  count: number;
  color: string;
}

const ParticleCloud: React.FC<ParticleCloudProps> = ({ count, color }) => {
  const pointsRef = useRef<THREE.Points>(null);
  const { positions, colors } = useMemo(() => generateParticles(count), [count]);

  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    return geo;
  }, [positions, colors]);

  useFrame((state) => {
    if (!pointsRef.current) return;
    pointsRef.current.rotation.x = state.clock.getElapsedTime() * 0.05;
    pointsRef.current.rotation.y = state.clock.getElapsedTime() * 0.04;
  });

  return (
    <Points ref={pointsRef} geometry={geometry}>
      <PointMaterial
        transparent
        vertexColors
        size={0.05}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        opacity={0.8}
      />
    </Points>
  );
};

export const ParticleBackground: React.FC = () => {
  const { theme } = useTheme();

  return (
    <div className="three-canvas">
      <Canvas
        camera={{ position: [0, 0, 5], fov: 60 }}
        style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: -1 }}
        dpr={[1, 2]}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: 'high-performance'
        }}
      >
        <ParticleCloud 
          count={1500}
          color={theme === 'light' ? '#8b5cf6' : '#6d28d9'} 
        />
      </Canvas>
    </div>
  );
};