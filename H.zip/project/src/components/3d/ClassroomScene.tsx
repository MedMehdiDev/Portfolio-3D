import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Text3D, Center, OrbitControls } from '@react-three/drei';
import { motion } from 'framer-motion-3d';
import { useTheme } from '../../context/ThemeContext';
import * as THREE from 'three';

const TeachingScene = () => {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = Math.sin(state.clock.getElapsedTime() * 0.2) * 0.1;
  });

  return (
    <group ref={groupRef}>
      <Float
        speed={1.5}
        rotationIntensity={0.5}
        floatIntensity={0.5}
      >
        <Center>
          <Text3D
            font="/fonts/inter_bold.json"
            size={0.5}
            height={0.2}
            curveSegments={12}
            bevelEnabled
            bevelThickness={0.02}
            bevelSize={0.02}
            bevelOffset={0}
            bevelSegments={5}
          >
            {`ENGLISH\nTUTOR`}
            <meshPhysicalMaterial
              color="#8b5cf6"
              metalness={0.8}
              roughness={0.2}
              clearcoat={1}
              clearcoatRoughness={0.2}
            />
          </Text3D>
        </Center>

        {/* Floating educational symbols */}
        <motion.group
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          position={[2, 0, 0]}
        >
          <mesh>
            <torusGeometry args={[0.3, 0.1, 16, 32]} />
            <meshPhysicalMaterial
              color="#ec4899"
              metalness={0.6}
              roughness={0.3}
              clearcoat={1}
            />
          </mesh>
        </motion.group>

        <motion.group
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1, delay: 0.7 }}
          position={[-2, 0, 0]}
        >
          <mesh>
            <octahedronGeometry args={[0.4]} />
            <meshPhysicalMaterial
              color="#14b8a6"
              metalness={0.6}
              roughness={0.3}
              clearcoat={1}
            />
          </mesh>
        </motion.group>

        {/* Animated particles */}
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.mesh
            key={i}
            position={[
              (Math.random() - 0.5) * 5,
              (Math.random() - 0.5) * 5,
              (Math.random() - 0.5) * 5
            ]}
            initial={{ scale: 0 }}
            animate={{ scale: 0.1 }}
            transition={{
              duration: 1,
              delay: i * 0.1,
              repeat: Infinity,
              repeatType: "reverse"
            }}
          >
            <sphereGeometry args={[1, 16, 16]} />
            <meshPhysicalMaterial
              color="#6d28d9"
              metalness={0.8}
              roughness={0.2}
              transparent
              opacity={0.6}
            />
          </motion.mesh>
        ))}
      </Float>
    </group>
  );
};

export const ClassroomScene: React.FC = () => {
  const { theme } = useTheme();
  
  return (
    <div className="h-[400px] md:h-[600px] w-full">
      <Canvas dpr={[1, 2]} camera={{ position: [0, 0, 8], fov: 45 }}>
        <color attach="background" args={[theme === 'light' ? '#f8fafc' : '#020617']} />
        <ambientLight intensity={0.5} />
        <spotLight
          position={[10, 10, 10]}
          angle={0.15}
          penumbra={1}
          intensity={1}
          castShadow
        />
        <pointLight position={[-10, -10, -10]} intensity={0.5} />
        <TeachingScene />
        <OrbitControls
          enablePan={false}
          enableZoom={false}
          minPolarAngle={Math.PI / 3}
          maxPolarAngle={Math.PI / 1.5}
          dampingFactor={0.05}
          rotateSpeed={0.5}
        />
      </Canvas>
    </div>
  );
};