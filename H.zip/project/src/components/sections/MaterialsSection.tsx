import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Video, Image, Presentation, Download, ExternalLink } from 'lucide-react';
import { materials } from '../../data/materialsData';

const MaterialsSection: React.FC = () => {
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return <FileText className="w-5 h-5" />;
      case 'video':
        return <Video className="w-5 h-5" />;
      case 'image':
        return <Image className="w-5 h-5" />;
      case 'slides':
        return <Presentation className="w-5 h-5" />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  return (
    <section id="resources" className="py-16 md:py-24 relative">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="section-title">Free Learning Resources</h2>
          <p className="subtitle">
            Helpful materials to support your English learning journey
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {materials.map((material, index) => (
            <motion.div
              key={material.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-card overflow-hidden group"
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={material.thumbnail}
                  alt={material.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-lg font-display font-semibold text-primary-700 dark:text-primary-400">
                    {material.title}
                  </h3>
                  <span className="flex items-center space-x-1 text-xs bg-primary-100 dark:bg-primary-900/50 text-primary-700 dark:text-primary-400 px-2 py-1 rounded-full">
                    {getTypeIcon(material.type)}
                    <span className="uppercase">{material.type}</span>
                  </span>
                </div>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                  {material.description}
                </p>
                <div className="flex justify-between items-center">
                  <a
                    href={material.url}
                    className="flex items-center text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 text-sm font-medium"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </a>
                  <a
                    href={material.url}
                    className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 text-sm"
                  >
                    Preview
                    <ExternalLink className="w-4 h-4 ml-1" />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
            These resources are just a sample of the comprehensive materials available to my students. 
            Book a trial lesson to access the full range of teaching materials tailored to your needs.
          </p>
          <a
            href="https://preply.com/en/tutor/1417036"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Book a Trial Lesson
          </a>
        </motion.div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/3 right-0 w-64 h-64 rounded-full bg-primary-200/20 dark:bg-primary-900/20 blur-3xl -z-10"></div>
    </section>
  );
};

export default MaterialsSection;