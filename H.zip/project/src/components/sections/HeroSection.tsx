import React from 'react';
import { motion } from 'framer-motion';

const HeroSection: React.FC = () => {
  return (
    <section className="relative pt-32 pb-16 md:pt-40 md:pb-24 overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-center lg:text-left"
          >
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-6xl font-display font-bold leading-tight text-primary-800 dark:text-primary-300 mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <span className="block">Hi, I'm Hassna Ben –</span>
              <span className="relative inline-block text-transparent bg-clip-text bg-gradient-to-r from-primary-600 to-secondary-500">
                CELTA-Certified
              </span>{' '}
              English Teacher
            </motion.h1>
            
            <motion.p 
              className="text-xl text-gray-600 dark:text-gray-400 mb-8 max-w-lg mx-auto lg:mx-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              Let's unlock your fluency together with personalized lessons tailored to your goals.
            </motion.p>
            
            <motion.div
              className="flex flex-col sm:flex-row justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <a
                href="https://preply.com/en/tutor/1417036"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Book a Trial on Preply
              </a>
              <a href="#about" className="btn-secondary">
                Learn More
              </a>
            </motion.div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="glass-card p-6 rounded-xl overflow-hidden"
          >
            <div className="aspect-video rounded-lg overflow-hidden">
              <iframe 
                title="Teacher Introduction" 
                src="https://player.vimeo.com/video/618960353?h=1f76194d3b" 
                width="100%" 
                height="100%" 
                frameBorder="0" 
                allowFullScreen
                className="w-full h-full"
              />
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-primary-200/30 dark:bg-primary-800/20 blur-3xl"></div>
      <div className="absolute top-1/2 -left-32 w-64 h-64 rounded-full bg-secondary-200/30 dark:bg-secondary-800/20 blur-3xl"></div>
    </section>
  );
};

export default HeroSection;