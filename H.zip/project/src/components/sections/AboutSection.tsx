import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { CheckCircle, Award, GraduationCap, BookOpen, Globe } from 'lucide-react';
import { TimelineItemType } from '../../types';

const timelineItems: TimelineItemType[] = [
  {
    id: 1,
    year: '2012-2016',
    title: 'English Degree',
    description: 'Completed Bachelor\'s degree in English Studies with honors',
    icon: 'GraduationCap',
  },
  {
    id: 2,
    year: '2018',
    title: 'CELTA Certificate',
    description: 'Earned Cambridge CELTA certification for teaching English as a second language',
    icon: 'Award',
  },
  {
    id: 3,
    year: '2018-Present',
    title: '7+ Years Experience',
    description: 'Teaching students from diverse backgrounds and skill levels worldwide',
    icon: 'Globe',
  },
  {
    id: 4,
    year: '2020-Present',
    title: 'Full-time Preply Tutor',
    description: 'Dedicated online English teacher with high satisfaction ratings',
    icon: 'BookOpen',
  },
];

interface TimelineItemProps {
  item: TimelineItemType;
  index: number;
}

const TimelineItem: React.FC<TimelineItemProps> = ({ item, index }) => {
  const renderIcon = () => {
    switch (item.icon) {
      case 'GraduationCap':
        return <GraduationCap className="w-6 h-6" />;
      case 'Award':
        return <Award className="w-6 h-6" />;
      case 'Globe':
        return <Globe className="w-6 h-6" />;
      case 'BookOpen':
        return <BookOpen className="w-6 h-6" />;
      default:
        return <CheckCircle className="w-6 h-6" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      viewport={{ once: true, margin: "-100px" }}
      className={`flex ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} flex-col md:gap-8 mb-12`}
    >
      <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'} mb-4 md:mb-0`}>
        <h3 className="text-xl font-display font-semibold text-primary-700 dark:text-primary-400">
          {item.title}
        </h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm mb-2">
          {item.year}
        </p>
        <p className="text-gray-600 dark:text-gray-300">
          {item.description}
        </p>
      </div>
      
      <div className="md:w-12 flex justify-center">
        <div className="relative">
          <div className="h-full w-0.5 bg-primary-300 dark:bg-primary-700 absolute left-1/2 transform -translate-x-1/2"></div>
          <div className="rounded-full bg-primary-100 dark:bg-primary-900 p-2 border-2 border-primary-500 dark:border-primary-600 text-primary-600 dark:text-primary-400 relative z-10">
            {renderIcon()}
          </div>
        </div>
      </div>
      
      <div className="md:w-1/2"></div>
    </motion.div>
  );
};

const AboutSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);

  return (
    <section id="about" ref={sectionRef} className="py-16 md:py-24 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="section-title">About Me</h2>
          <p className="subtitle">
            Passionate about teaching and dedicated to helping students achieve fluency
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div 
            style={{ y }}
            className="glass-card p-6 md:p-8 rounded-xl"
          >
            <motion.img
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              src="https://avatars.preply.com/i/logos/i/logos/avatar_21wbxx09dke.jpg" 
              alt="English Teacher" 
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-display font-semibold text-primary-700 dark:text-primary-400 mb-4">
              Hello! I'm Hassna
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              I'm a CELTA-certified English teacher from Morocco with over 7 years of experience teaching students from around the world. I'm passionate about creating engaging, personalized learning experiences that help my students achieve fluency with confidence.
            </p>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              When I'm not teaching, I enjoy reading, swimming, and learning about different cultures. I believe that language learning should be fun, interactive, and relevant to your personal goals.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-primary-600 dark:text-primary-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Fluent in</h4>
                  <p className="text-gray-600 dark:text-gray-400">English, Arabic (C1), French (C1)</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-primary-600 dark:text-primary-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Teaching Style</h4>
                  <p className="text-gray-600 dark:text-gray-400">Interactive, student-centered</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-primary-600 dark:text-primary-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Education</h4>
                  <p className="text-gray-600 dark:text-gray-400">CELTA Certification, English Degree</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-primary-600 dark:text-primary-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Platform</h4>
                  <p className="text-gray-600 dark:text-gray-400">Full-time Preply Tutor</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
        
        <div className="mt-20">
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-2xl font-display font-semibold text-center text-primary-700 dark:text-primary-400 mb-12"
          >
            My Journey
          </motion.h3>
          
          <div className="relative">
            <div className="absolute h-full w-0.5 bg-primary-300 dark:bg-primary-700 left-1/2 transform -translate-x-1/2 hidden md:block"></div>
            {timelineItems.map((item, index) => (
              <TimelineItem key={item.id} item={item} index={index} />
            ))}
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute bottom-0 right-0 w-72 h-72 rounded-full bg-accent-200/20 dark:bg-accent-900/20 blur-3xl -z-10"></div>
    </section>
  );
};

export default AboutSection;