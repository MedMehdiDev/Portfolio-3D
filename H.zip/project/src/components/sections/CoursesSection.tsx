import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { courses } from '../../data/courseData';
import { MessageCircle, Briefcase, BookOpen, Flag, Plane, User, GraduationCap, Globe } from 'lucide-react';

const CoursesSection: React.FC = () => {
  const [activeCard, setActiveCard] = useState<number | null>(null);

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'MessageCircle':
        return <MessageCircle className="w-6 h-6" />;
      case 'Briefcase':
        return <Briefcase className="w-6 h-6" />;
      case 'BookOpen':
        return <BookOpen className="w-6 h-6" />;
      case 'Flag':
        return <Flag className="w-6 h-6" />;
      case 'Plane':
        return <Plane className="w-6 h-6" />;
      case 'User':
        return <User className="w-6 h-6" />;
      case 'GraduationCap':
        return <GraduationCap className="w-6 h-6" />;
      case 'Globe':
        return <Globe className="w-6 h-6" />;
      default:
        return <BookOpen className="w-6 h-6" />;
    }
  };

  const handleCardClick = (id: number) => {
    if (activeCard === id) {
      setActiveCard(null);
    } else {
      setActiveCard(id);
    }
  };

  return (
    <section id="courses" className="py-16 md:py-24 relative">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="section-title">Courses Offered</h2>
          <p className="subtitle">
            Specialized English courses designed to meet your specific goals and interests
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {courses.map((course, index) => (
            <motion.div
              key={course.id}
              className="relative h-[280px] perspective-500"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <motion.div
                className="w-full h-full preserve-3d cursor-pointer transition-all duration-500"
                animate={{ 
                  rotateY: activeCard === course.id ? 180 : 0,
                }}
              >
                {/* Front of Card */}
                <div 
                  className="absolute w-full h-full backface-hidden glass-card p-6 overflow-hidden flex flex-col justify-between"
                  onClick={() => handleCardClick(course.id)}
                >
                  <div className="flex justify-between items-start">
                    <div className="bg-primary-100 dark:bg-primary-900/50 p-3 rounded-full text-primary-600 dark:text-primary-400">
                      {getIconComponent(course.icon)}
                    </div>
                    <span className="text-xs font-medium text-primary-600 dark:text-primary-400 bg-primary-100 dark:bg-primary-900/50 px-2 py-1 rounded-full">
                      {`Course ${course.id}`}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xl font-display font-semibold text-primary-700 dark:text-primary-400 mb-2">
                      {course.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm">
                      {course.description}
                    </p>
                  </div>

                  <div className="text-center mt-4">
                    <span className="text-sm text-primary-600 dark:text-primary-400 font-medium">
                      Click to see details
                    </span>
                  </div>
                </div>

                {/* Back of Card */}
                <div 
                  className="absolute w-full h-full backface-hidden glass-card p-6 rotateY-180 overflow-auto"
                  onClick={() => handleCardClick(course.id)}
                >
                  <h3 className="text-lg font-display font-semibold text-primary-700 dark:text-primary-400 mb-3">
                    {course.title}
                  </h3>

                  <div className="mb-3">
                    <h4 className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-1">Goals:</h4>
                    <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1 list-disc pl-4">
                      {course.goals.map((goal, i) => (
                        <li key={i}>{goal}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-3">
                    <h4 className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-1">Methods:</h4>
                    <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1 list-disc pl-4">
                      {course.methods.map((method, i) => (
                        <li key={i}>{method}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="text-center mt-2">
                    <span className="text-xs text-primary-600 dark:text-primary-400 font-medium">
                      Click to flip back
                    </span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            All courses can be customized to match your specific needs and learning pace.
          </p>
          <a
            href="https://preply.com/en/tutor/1417036"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Book a Trial Lesson
          </a>
        </motion.div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/3 left-0 w-64 h-64 rounded-full bg-accent-200/20 dark:bg-accent-900/20 blur-3xl -z-10"></div>
    </section>
  );
};

export default CoursesSection;