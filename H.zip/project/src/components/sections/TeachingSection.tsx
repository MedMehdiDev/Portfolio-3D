import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Clock, BookOpen, MessageCircle, Award, Sparkles } from 'lucide-react';

const teachingQualities = [
  {
    id: 1,
    title: 'Enthusiastic',
    description: 'I bring positive energy to every lesson to keep you motivated',
    icon: Sparkles,
  },
  {
    id: 2,
    title: 'Patient',
    description: 'Learning takes time, and I provide a supportive, no-pressure environment',
    icon: Heart,
  },
  {
    id: 3,
    title: 'Punctual',
    description: 'I respect your time and ensure lessons start and end as scheduled',
    icon: Clock,
  },
  {
    id: 4,
    title: 'Adaptable',
    description: 'My teaching style adjusts to your unique learning needs and pace',
    icon: BookOpen,
  },
  {
    id: 5,
    title: 'Engaging',
    description: 'I create interactive lessons that make learning English enjoyable',
    icon: MessageCircle,
  },
  {
    id: 6,
    title: 'Professional',
    description: 'CELTA-certified with structured lesson plans and proper methodology',
    icon: Award,
  },
];

interface TeachingQualityCardProps {
  title: string;
  description: string;
  icon: React.ElementType;
  index: number;
}

const TeachingQualityCard: React.FC<TeachingQualityCardProps> = ({ 
  title, 
  description, 
  icon: Icon,
  index 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true, margin: "-50px" }}
      className="glass-card p-6 hover:shadow-xl transition-all duration-300 group"
    >
      <div className="bg-primary-100 dark:bg-primary-900/50 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4 text-primary-600 dark:text-primary-400 group-hover:text-white group-hover:bg-primary-600 dark:group-hover:bg-primary-500 transition-colors duration-300">
        <Icon size={24} />
      </div>
      <h3 className="text-xl font-display font-semibold text-primary-700 dark:text-primary-400 mb-2">
        {title}
      </h3>
      <p className="text-gray-600 dark:text-gray-400">
        {description}
      </p>
    </motion.div>
  );
};

const TeachingSection: React.FC = () => {
  return (
    <section id="teaching" className="py-16 md:py-24 bg-gray-50/50 dark:bg-gray-900/20 relative">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="section-title">My Teaching Style</h2>
          <p className="subtitle">
            A student-centered approach that focuses on your goals and learning preferences
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {teachingQualities.map((quality, index) => (
            <TeachingQualityCard
              key={quality.id}
              title={quality.title}
              description={quality.description}
              icon={quality.icon}
              index={index}
            />
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-display font-semibold text-primary-700 dark:text-primary-400 mb-4">
              How I Help You Succeed
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              My teaching approach is based on creating a comfortable, encouraging environment where you can practice English without fear of making mistakes. I believe in learning through real conversation and practical exercises.
            </p>

            <div className="space-y-4">
              <div className="glass-card p-4 flex items-start space-x-4">
                <div className="bg-secondary-100 dark:bg-secondary-900/50 p-2 rounded-full text-secondary-600 dark:text-secondary-400">
                  <span className="font-bold">1</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Personalized Learning Plan</h4>
                  <p className="text-gray-600 dark:text-gray-400">We start by identifying your goals and creating a customized learning path</p>
                </div>
              </div>

              <div className="glass-card p-4 flex items-start space-x-4">
                <div className="bg-secondary-100 dark:bg-secondary-900/50 p-2 rounded-full text-secondary-600 dark:text-secondary-400">
                  <span className="font-bold">2</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Immersive Conversation</h4>
                  <p className="text-gray-600 dark:text-gray-400">Regular speaking practice to build confidence and fluency</p>
                </div>
              </div>

              <div className="glass-card p-4 flex items-start space-x-4">
                <div className="bg-secondary-100 dark:bg-secondary-900/50 p-2 rounded-full text-secondary-600 dark:text-secondary-400">
                  <span className="font-bold">3</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Real-time Feedback</h4>
                  <p className="text-gray-600 dark:text-gray-400">Gentle correction and pronunciation guidance during our sessions</p>
                </div>
              </div>

              <div className="glass-card p-4 flex items-start space-x-4">
                <div className="bg-secondary-100 dark:bg-secondary-900/50 p-2 rounded-full text-secondary-600 dark:text-secondary-400">
                  <span className="font-bold">4</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-gray-200">Homework & Resources</h4>
                  <p className="text-gray-600 dark:text-gray-400">Additional materials to reinforce what you've learned between lessons</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-card p-6 md:p-8 rounded-xl"
          >
            <img
              src="https://images.pexels.com/photos/5905700/pexels-photo-5905700.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" 
              alt="Teaching English Online" 
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </motion.div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 -left-20 w-64 h-64 rounded-full bg-secondary-200/20 dark:bg-secondary-900/20 blur-3xl -z-10"></div>
      <div className="absolute bottom-20 right-0 w-72 h-72 rounded-full bg-primary-200/20 dark:bg-primary-900/20 blur-3xl -z-10"></div>
    </section>
  );
};

export default TeachingSection;