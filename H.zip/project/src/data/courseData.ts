import { CourseType } from '../types';

export const courses: CourseType[] = [
  {
    id: 1,
    title: 'General English',
    description: 'Comprehensive English learning for all aspects of life',
    goals: [
      'Balanced skills development',
      'Grammar and vocabulary mastery',
      'Real-world communication skills',
      'Cultural understanding'
    ],
    methods: [
      'Integrated skills approach',
      'Grammar in context',
      'Interactive video lessons',
      'Regular progress assessments'
    ],
    preview: 'Develop well-rounded English skills for work, travel, and everyday life.',
    icon: 'Globe'
  },
  {
    id: 2,
    title: 'Business English',
    description: 'Professional English for workplace communication',
    goals: [
      'Conduct meetings confidently',
      'Write professional emails',
      'Give effective presentations',
      'Negotiate and discuss projects'
    ],
    methods: [
      'Business case studies',
      'Email writing practice',
      'Presentation skills workshops',
      'Work-related vocabulary building'
    ],
    preview: 'Enhance your professional communication skills for global business environments.',
    icon: 'Briefcase'
  },
  {
    id: 3,
    title: 'English for Beginners',
    description: 'Start your English journey with strong foundations',
    goals: [
      'Master basic grammar structures',
      'Build essential vocabulary',
      'Develop simple conversation skills',
      'Understand basic written English'
    ],
    methods: [
      'Interactive video lessons',
      'Structured grammar lessons',
      'Simple role-play activities',
      'Gradual progression approach'
    ],
    preview: 'Begin your English learning journey with confidence through step-by-step lessons.',
    icon: 'BookOpen'
  },
  {
    id: 4,
    title: 'IELTS Preparation',
    description: 'Comprehensive preparation for IELTS success',
    goals: [
      'Understand exam format and requirements',
      'Master test-taking strategies',
      'Improve all four skills',
      'Achieve target band score'
    ],
    methods: [
      'Practice tests and feedback',
      'Targeted skill development',
      'Time management strategies',
      'Individual weakness analysis'
    ],
    preview: 'Get the IELTS score you need with personalized preparation.',
    icon: 'GraduationCap'
  },
  {
    id: 5,
    title: 'TOEFL Preparation',
    description: 'Expert guidance for TOEFL exam success',
    goals: [
      'Master TOEFL-specific strategies',
      'Improve academic English skills',
      'Practice with authentic materials',
      'Build test confidence'
    ],
    methods: [
      'Mock tests and analysis',
      'Section-specific training',
      'Score improvement strategies',
      'Academic vocabulary focus'
    ],
    preview: 'Prepare effectively for TOEFL with specialized coaching.',
    icon: 'Award'
  },
  {
    id: 6,
    title: 'Interview Preparation',
    description: 'Ace your English interview with confidence',
    goals: [
      'Answer common interview questions',
      'Discuss your skills professionally',
      'Ask appropriate questions',
      'Make a positive impression'
    ],
    methods: [
      'Mock interviews',
      'CV and cover letter review',
      'Professional vocabulary building',
      'Body language and etiquette'
    ],
    preview: 'Prepare thoroughly for job interviews conducted in English.',
    icon: 'User'
  }
];