import { ReviewType } from '../types';

export const reviews: ReviewType[] = [
  {
    id: 1,
    name: "Sophia K.",
    country: "Germany",
    flag: "🇩🇪",
    text: "Hassna is an exceptional teacher! She tailors each lesson to my needs and makes learning English enjoyable. My confidence has grown tremendously since we started working together.",
    rating: 5
  },
  {
    id: 2,
    name: "Ahmed M.",
    country: "Saudi Arabia",
    flag: "🇸🇦",
    text: "I've tried many English teachers before, but Hassna truly stands out. Her patience and structured approach helped me improve my business English skills within just a few months.",
    rating: 5
  },
  {
    id: 3,
    name: "Elena P.",
    country: "Russia",
    flag: "🇷🇺",
    text: "Hassna helped me prepare for my IELTS exam, and I achieved a higher score than I expected! She knows exactly what to focus on and provides excellent learning materials.",
    rating: 5
  },
  {
    id: 4,
    name: "Carlos R.",
    country: "Brazil",
    flag: "🇧🇷",
    text: "Lessons with Hassna are always engaging and productive. She corrects my pronunciation in a kind way and explains grammar concepts clearly. Highly recommended!",
    rating: 5
  },
  {
    id: 5,
    name: "Yuki T.",
    country: "Japan",
    flag: "🇯🇵",
    text: "I was very shy about speaking English, but Hassna created such a comfortable environment that I now look forward to our conversations. My progress has been remarkable.",
    rating: 5
  },
  {
    id: 6,
    name: "Pierre L.",
    country: "France",
    flag: "🇫🇷",
    text: "As a business professional, I needed to improve my English quickly. Hassna's specialized business English course was exactly what I needed. She's professional and effective.",
    rating: 5
  },
  {
    id: 7,
    name: "Maria G.",
    country: "Spain",
    flag: "🇪🇸",
    text: "I've been taking lessons with Hassna for over a year now. She keeps the classes interesting with varied topics and activities. My English has improved dramatically!",
    rating: 5
  },
  {
    id: 8,
    name: "Ji-hoon K.",
    country: "South Korea",
    flag: "🇰🇷",
    text: "Hassna helped me prepare for my university interviews in English. Her interview preparation course was comprehensive and gave me the confidence I needed to succeed.",
    rating: 4
  }
];