import { DemoMaterialType } from '../types';

export const materials: DemoMaterialType[] = [
  {
    id: 1,
    title: "Pronunciation Guide",
    description: "Master English phonetics and reduce your accent",
    type: "pdf",
    url: "#",
    thumbnail: "https://images.pexels.com/photos/4144923/pexels-photo-4144923.jpeg?auto=compress&cs=tinysrgb&w=600"
  },
  {
    id: 2,
    title: "Common English Phrases",
    description: "Essential phrases for everyday conversations",
    type: "pdf",
    url: "#",
    thumbnail: "https://images.pexels.com/photos/4439901/pexels-photo-4439901.jpeg?auto=compress&cs=tinysrgb&w=600"
  },
  {
    id: 3,
    title: "Grammar Essentials",
    description: "Key grammar rules explained simply",
    type: "pdf",
    url: "#",
    thumbnail: "https://images.pexels.com/photos/6936859/pexels-photo-6936859.jpeg?auto=compress&cs=tinysrgb&w=600"
  },
  {
    id: 4,
    title: "Speaking Practice Demo",
    description: "Sample speaking lesson with pronunciation tips",
    type: "video",
    url: "#",
    thumbnail: "https://images.pexels.com/photos/7516363/pexels-photo-7516363.jpeg?auto=compress&cs=tinysrgb&w=600"
  },
  {
    id: 5,
    title: "Business English Vocabulary",
    description: "Essential terms for professional settings",
    type: "pdf",
    url: "#",
    thumbnail: "https://images.pexels.com/photos/6457518/pexels-photo-6457518.jpeg?auto=compress&cs=tinysrgb&w=600"
  },
  {
    id: 6,
    title: "Conversation Starters",
    description: "Topics and questions to practice English speaking",
    type: "slides",
    url: "#",
    thumbnail: "https://images.pexels.com/photos/7092613/pexels-photo-7092613.jpeg?auto=compress&cs=tinysrgb&w=600"
  }
];